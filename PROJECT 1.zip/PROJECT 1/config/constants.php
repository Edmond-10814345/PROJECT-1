<?php

define('EMAIL','cpenproject1@gmail.com');
define('PASSWORD', 'cpenproject1_10814345');


define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'user-verification');